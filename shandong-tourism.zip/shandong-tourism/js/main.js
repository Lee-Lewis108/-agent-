// ===== Navbar Scroll Effect =====
const header = document.querySelector('.header');
window.addEventListener('scroll', () => {
  header.classList.toggle('scrolled', window.scrollY > 50);
});

// ===== Mobile Menu Toggle =====
const hamburger = document.querySelector('.hamburger');
const navLinks = document.querySelector('.nav-links');
if (hamburger) {
  hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('open');
    navLinks.classList.toggle('open');
  });
  // Close menu on link click
  navLinks.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      hamburger.classList.remove('open');
      navLinks.classList.remove('open');
    });
  });
}

// ===== Scroll Animations =====
const observerOptions = { threshold: 0.1, rootMargin: '0px 0px -50px 0px' };
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, observerOptions);

document.querySelectorAll('.fade-up').forEach(el => observer.observe(el));

// ===== Counter Animation =====
function animateCounter(el, target) {
  let current = 0;
  const increment = target / 60;
  const timer = setInterval(() => {
    current += increment;
    if (current >= target) {
      current = target;
      clearInterval(timer);
    }
    el.textContent = Math.floor(current).toLocaleString();
  }, 16);
}

const counterObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const target = parseInt(entry.target.dataset.target);
      animateCounter(entry.target, target);
      counterObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.5 });

document.querySelectorAll('.num[data-target]').forEach(el => counterObserver.observe(el));

// ===== Gallery Lightbox =====
const galleryItems = document.querySelectorAll('.gallery-item');
if (galleryItems.length > 0) {
  // Create lightbox
  const lightbox = document.createElement('div');
  lightbox.style.cssText = `
    position:fixed;inset:0;background:rgba(0,0,0,.9);z-index:9999;
    display:none;align-items:center;justify-content:center;cursor:pointer;
    opacity:0;transition:opacity .3s;
  `;
  lightbox.innerHTML = `
    <div style="max-width:80vw;max-height:80vh;text-align:center;">
      <div id="lb-img" style="width:70vw;height:60vh;background-size:contain;background-position:center;background-repeat:no-repeat;margin:0 auto;border-radius:12px;"></div>
      <p id="lb-caption" style="color:#fff;margin-top:16px;font-size:1.1rem;"></p>
    </div>
  `;
  document.body.appendChild(lightbox);

  galleryItems.forEach(item => {
    item.addEventListener('click', () => {
      const bg = getComputedStyle(item).backgroundImage;
      const caption = item.querySelector('.caption')?.textContent || '';
      lightbox.querySelector('#lb-img').style.backgroundImage = bg;
      lightbox.querySelector('#lb-caption').textContent = caption;
      lightbox.style.display = 'flex';
      requestAnimationFrame(() => lightbox.style.opacity = '1');
    });
  });

  lightbox.addEventListener('click', () => {
    lightbox.style.opacity = '0';
    setTimeout(() => lightbox.style.display = 'none', 300);
  });
}

// ===== Smooth page transitions =====
document.querySelectorAll('a[href$=".html"]').forEach(link => {
  if (link.hostname === window.location.hostname) {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      document.body.style.opacity = '0';
      document.body.style.transition = 'opacity .3s';
      setTimeout(() => { window.location.href = link.href; }, 300);
    });
  }
});

// Fade in on page load
window.addEventListener('DOMContentLoaded', () => {
  document.body.style.opacity = '0';
  requestAnimationFrame(() => {
    document.body.style.transition = 'opacity .4s';
    document.body.style.opacity = '1';
  });
});
