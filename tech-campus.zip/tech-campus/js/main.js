// ===== Navbar =====
const navbar=document.querySelector('.navbar');
window.addEventListener('scroll',()=>{
  navbar.classList.toggle('scrolled',window.scrollY>60);
});

// ===== Mobile Menu =====
const hamburger=document.querySelector('.hamburger');
const navLinks=document.querySelector('.nav-links');
if(hamburger){
  hamburger.addEventListener('click',()=>{
    hamburger.classList.toggle('open');
    navLinks.classList.toggle('open');
  });
  navLinks.querySelectorAll('a').forEach(l=>{
    l.addEventListener('click',()=>{
      hamburger.classList.remove('open');
      navLinks.classList.remove('open');
    });
  });
}

// ===== Scroll Reveal =====
const revealObserver=new IntersectionObserver((entries)=>{
  entries.forEach(e=>{
    if(e.isIntersecting){
      e.target.classList.add('visible');
      revealObserver.unobserve(e.target);
    }
  });
},{threshold:0.12,rootMargin:'0px 0px -40px 0px'});
document.querySelectorAll('.reveal').forEach(el=>revealObserver.observe(el));

// ===== Counter Animation =====
function animateNum(el,target,suffix=''){
  let cur=0;const step=target/60;
  const t=setInterval(()=>{
    cur+=step;
    if(cur>=target){cur=target;clearInterval(t);}
    el.textContent=Math.floor(cur).toLocaleString()+suffix;
  },16);
}
const counterObs=new IntersectionObserver((entries)=>{
  entries.forEach(e=>{
    if(e.isIntersecting){
      const target=parseInt(e.target.dataset.target);
      const suffix=e.target.dataset.suffix||'';
      animateNum(e.target,target,suffix);
      counterObs.unobserve(e.target);
    }
  });
},{threshold:0.5});
document.querySelectorAll('[data-counter]').forEach(el=>counterObs.observe(el));

// ===== Page Transitions =====
document.querySelectorAll('a[href$=".html"]').forEach(link=>{
  if(link.hostname===window.location.hostname){
    link.addEventListener('click',e=>{
      e.preventDefault();
      document.body.style.opacity='0';
      document.body.style.transition='opacity .25s';
      setTimeout(()=>{window.location.href=link.href;},250);
    });
  }
});
window.addEventListener('DOMContentLoaded',()=>{
  document.body.style.opacity='0';
  requestAnimationFrame(()=>{
    document.body.style.transition='opacity .35s';
    document.body.style.opacity='1';
  });
});

// ===== Parallax on hero orbs =====
document.addEventListener('mousemove',e=>{
  const orbs=document.querySelectorAll('.hero-orb');
  const x=(e.clientX/window.innerWidth-.5)*30;
  const y=(e.clientY/window.innerHeight-.5)*30;
  orbs.forEach((o,i)=>{
    const factor=i===0?1:-1;
    o.style.transform=`translate(${x*factor}px,${y*factor}px)`;
  });
});
